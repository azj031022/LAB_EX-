
# Social Media Computing - Lab Exercise 3

This repository contains the solution for Lab Exercise 3 (CDS-6344 Social Media Computing) — Sentiment Analysis using real-world dataset.

## Tasks Implemented

- Dependency-based parsing (Aspect Extraction)
- Unsupervised Machine Learning (KMeans Clustering)
- Supervised Machine Learning (Logistic Regression)

## Dataset

Dataset: `res_review.csv`  
Preprocessed to generate binary sentiment labels for supervised ML.

## Requirements

Install dependencies using:

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

## Running the Code

```bash
python lab3_sentiment_analysis.py
```
