
# lab3_sentiment_analysis.py

import pandas as pd
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

file_path = 'data/res_review.csv'
df = pd.read_csv(file_path)
df['label'] = df['rating'].apply(lambda x: 1 if x >= 4 else 0)
df = df[['text', 'label']]

nlp = spacy.load("en_core_web_sm")

def dependency_parsing(text):
    doc = nlp(text)
    aspects = []
    for token in doc:
        if token.dep_ in ('amod', 'acomp') and token.head.pos_ == 'NOUN':
            aspects.append((token.head.text, token.text))
    return aspects

df_sample = df.sample(10, random_state=42)
df_sample['aspects'] = df_sample['text'].apply(dependency_parsing)
print(df_sample[['text', 'aspects']])

vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
X_unsup = vectorizer.fit_transform(df['text'])

kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
kmeans.fit(X_unsup)
df['cluster'] = kmeans.labels_
print(df[['text', 'cluster']].head())

X_train, X_test, y_train, y_test = train_test_split(X_unsup, df['label'], test_size=0.3, random_state=42)
clf = LogisticRegression(max_iter=200)
clf.fit(X_train, y_train)
accuracy = clf.score(X_test, y_test)
print("Logistic Regression Accuracy:", accuracy)
